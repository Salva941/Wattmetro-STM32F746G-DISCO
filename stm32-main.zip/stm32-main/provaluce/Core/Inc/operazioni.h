/*
 * operazioni.h
 *
 *  Created on: Apr 30, 2023
 *      Author: pato-
 */
#include <stdint.h>

#ifndef SRC_OPERAZIONI_H_
#define SRC_OPERAZIONI_H_


extern void elabora(void);
extern void UART_Tx_String(char *string);
extern void print(void);


#endif /* SRC_OPERAZIONI_H_ */
